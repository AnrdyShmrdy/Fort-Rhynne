LEVEL CREATOR:
The level creator display is the level creator. A prompt will pop up asking you to enter the amount of blocks to use.
After entering the amount of blocks, click on the creator window when it pops up in order to use it.

The Controls Are:
WASD: moves the cursor by one block unit each key press 
ARROW KEYS: moves the cursor regularly.
BACKSPACE: deletes previously placed block
SPACE: places a block
R: resets cursor
Once you have reached the max amount of blocks, press space to confirm your completion and the window will close.

LEVEL.TXT:
The level coodinates are saved in a file called level. 
Removing the file will not cause errors if you open the level creator, because it will be created automatically. 
However, if you open the level tester or level display when the level.txt is not there, you will obviously encounter errors.
Each time you create a level, the level.txt file is written over, erasing your previous level with your current level.
The coordinates inside the level.txt are in pairs, with each even numbered line being an x coordinate and odd being y.
The pair of coordinates are in the order you placed each block in which they corrispond to.
The very first line indicates how many lines are in the document. If you add coordinates you must add 2 to it for each block you add, and vice versa.
Each line in the document is read, so lines without numbers will cause errors.

IN THIS VERSION:
Should you want to save your level, copy the level.txt and paste it somewhere.
Should you want to play a level you have created before, copy the text inside that file and paste it into the level.txt.
Should you want to edit your existing level, you must open the level.txt and change the numbers there.
